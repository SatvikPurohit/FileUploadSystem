// routes/upload.ts
import { ServerRoute } from "@hapi/hapi";
import Busboy from "busboy";
import type { BusboyConfig } from "busboy";
import fs from "fs";
import path from "path";
import mkdirp from "mkdirp";
import { UPLOADS_DIR } from "../config";
import { validateAuth } from "../utils/auth";
import prisma from "../prisma/prisma.client";

const routes: ServerRoute[] = [
  {
  method: 'POST',
  path: '/debug/busboy',
  options: { payload: { output: 'stream', parse: false, maxBytes: 25 * 1024 * 1024 } },
  handler: async (request, h) => {
    return await new Promise((resolve) => {
      const Busboy = require('busboy');
      const busboy = Busboy({ headers: request.raw.req.headers });
      let found = false;
      busboy.on('file', (fieldname: any, file: { on: (arg0: string, arg1: { (): void; (): void; }) => void; }, info: any) => {
        found = true;
        console.log('[busboy debug] fieldname', fieldname, 'info', info);
        // drain file
        file.on('data', () => {});
        file.on('end', () => {});
      });
      busboy.on('finish', () => resolve({ ok: true, found }));
      busboy.on('error', (err: any) => {
        console.error('[busboy debug] err', err);
        resolve(h.response({ error: String(err) }).code(415));
      });
      request.raw.req.pipe(busboy);
    });
  }
},
  {
    method: "POST",
    path: "/debug/raw-upload",
    options: {
      payload: { output: "stream", parse: false, maxBytes: 25 * 1024 * 1024 },
    },
    handler: async (request, h) => {
      console.log("[debug] headers:", request.raw.req.headers["content-type"]);
      const out = require("fs").createWriteStream("/tmp/hapi-raw-upload.bin");
      request.raw.req.pipe(out);
      return new Promise((resolve) => {
        out.on("finish", () => {
          const size = require("fs").statSync("/tmp/hapi-raw-upload.bin").size;
          console.log("[debug] saved raw upload size:", size);
          resolve({ ok: true, size });
        });
        out.on("error", (err: any) => {
          console.error("[debug] write error", err);
          resolve(h.response({ error: String(err) }).code(500));
        });
      });
    },
  },
  {
    method: "POST",
    path: "/api/upload",
    options: {
      payload: {
        output: "stream",
        parse: false,
        maxBytes: 20 * 1024 * 1024,
      },
    },
    handler: async (request, h) => {
      const decoded = await validateAuth(request);
      if (!decoded) return h.response({ message: "Unauthorized" }).code(401);

      return await new Promise((resolve) => {
        const config: BusboyConfig = {
          headers: request.raw.req.headers,
          limits: { fileSize: 20 * 1024 * 1024 },
        };

        const busboy = Busboy(config);

        const results: any[] = [];
        let fileFound = false;

        busboy.on(
          "file",
          (
            fieldname: string,
            file: NodeJS.ReadableStream,
            info: { filename: string; encoding: string; mimeType: string }
          ) => {
            fileFound = true;

            const { filename, mimeType } = info;
            const ts = Date.now();

            const safeName = `${ts}_${filename}`.replace(
              /[^a-zA-Z0-9-_.]/g,
              "_"
            );
            const userDir = path.join(
              UPLOADS_DIR,
              String((decoded as any).userId)
            );
            mkdirp.sync(userDir);

            const destPath = path.join(userDir, safeName);
            const writeStream = fs.createWriteStream(destPath);

            file.pipe(writeStream);

            writeStream.on("finish", async () => {
              try {
                const stats = fs.statSync(destPath);
                const doc = await prisma.document.create({
                  data: {
                    userId: Number((decoded as any).userId),
                    filename,
                    path: destPath,
                    contentType: mimeType,
                    size: stats.size,
                    uploadedAt: new Date(),
                    status: "success",
                  },
                });

                results.push({ id: doc.id, filename: doc.filename });
              } catch (err) {
                results.push({ error: "failed", filename });
              }
            });

            writeStream.on("error", () => {
              results.push({ error: "failed", filename });
            });
          }
        );

        busboy.on("finish", () => {
          if (!fileFound) {
            return resolve(h.response({ error: "No file uploaded" }).code(400));
          }
          resolve({ ok: true, results });
        });

        busboy.on("error", (err) => {
          console.error("Busboy error", err);
          resolve(h.response({ error: "Parse error" }).code(415));
        });

        request.raw.req.pipe(busboy);
      });
    },
  },
];

export default routes;
